% compare_results.m
% Phase 5: Side-by-side comparison of open-loop, PID, and gain-scheduled responses
% All three responses plotted on the same axes for the main result figure.

clear; clc; close all;

%% --- Plant ---
K   = 1;
tau = 0.5;
G   = tf(K, [tau 1]);

%% --- PID Controller (Zone 2 / mid-range gains — baseline tuned) ---
Kp = 3.0;  Ki = 2.0;  Kd = 0.05;
C_pid  = pid(Kp, Ki, Kd);
T_pid  = feedback(C_pid * G, 1);

%% --- Gain-Scheduled (representative: Zone 2 gains, same setpoint for fair comparison) ---
% For comparison we use the mid-throttle zone (Zone 2) gains at setpoint = 1
% to show improvement over baseline PID at the same operating point.
Kp_gs = 3.0;  Ki_gs = 2.0;  Kd_gs = 0.05;   % Zone 2 (same as PID for mid-range)
% Use Zone 3 gains to show the gain-scheduled advantage at high throttle
Kp_gs = 5.0;  Ki_gs = 1.0;  Kd_gs = 0.10;
C_gs   = pid(Kp_gs, Ki_gs, Kd_gs);
T_gs   = feedback(C_gs * G, 1);

%% --- Time Vector ---
t = 0:0.01:6;

%% --- Step Responses ---
[y_ol,  t_ol]  = step(G,     t);
[y_pid, t_pid] = step(T_pid, t);
[y_gs,  t_gs]  = step(T_gs,  t);

%% --- Combined Plot ---
figure('Name','Throttle-Motor Response Comparison','NumberTitle','off','Position',[100 100 820 500]);

plot(t_ol,  y_ol,  'r--', 'LineWidth', 2.0, 'DisplayName', 'Open-Loop (no controller)');
hold on;
plot(t_pid, y_pid, 'b-',  'LineWidth', 2.0, 'DisplayName', sprintf('PID  (Kp=%.1f, Ki=%.1f, Kd=%.2f)', Kp, Ki, Kd));
plot(t_gs,  y_gs,  'g-',  'LineWidth', 2.0, 'DisplayName', sprintf('Gain-Scheduled / Zone3  (Kp=%.1f, Ki=%.1f, Kd=%.2f)', Kp_gs, Ki_gs, Kd_gs));
yline(1.0, 'k:', 'Setpoint', 'LineWidth', 1.2, 'LabelHorizontalAlignment','right');

%% --- Performance Annotations ---
info_pid = stepinfo(T_pid);
info_gs  = stepinfo(T_gs);
xline(info_pid.RiseTime, 'b:', sprintf('PID RT=%.2fs', info_pid.RiseTime), ...
    'LabelVerticalAlignment','bottom','Color',[0.2 0.2 0.9],'FontSize',8);
xline(info_gs.RiseTime,  'g:', sprintf('GS RT=%.2fs', info_gs.RiseTime), ...
    'LabelVerticalAlignment','top','Color',[0.1 0.6 0.1],'FontSize',8);

title('Throttle–Motor Response Comparison: Open-Loop vs PID vs Gain-Scheduled', ...
    'FontSize', 13, 'FontWeight', 'bold');
xlabel('Time (seconds)', 'FontSize', 11);
ylabel('Motor Speed (normalised)', 'FontSize', 11);
legend('Location','southeast','FontSize',10);
grid on; box on;
ylim([0 1.3]);

%% --- Printed Summary Table ---
[peak_pid, ~] = max(y_pid);
[peak_gs,  ~] = max(y_gs);
os_pid = (peak_pid - y_pid(end)) / y_pid(end) * 100;
os_gs  = (peak_gs  - y_gs(end))  / y_gs(end)  * 100;
sse_pid = abs(1 - y_pid(end)) * 100;
sse_gs  = abs(1 - y_gs(end))  * 100;

fprintf('\n========== Comparison Summary ==========\n');
fprintf('%-22s  %-12s  %-12s  %-12s\n', 'Metric', 'Open-Loop', 'PID', 'Gain-Sched');
fprintf('%-22s  %-12.4f  %-12.4f  %-12.4f\n', 'Rise Time (s)',      stepinfo(G).RiseTime,     info_pid.RiseTime,    info_gs.RiseTime);
fprintf('%-22s  %-12.2f  %-12.2f  %-12.2f\n', 'Overshoot (%%)',     stepinfo(G).Overshoot,    os_pid,               os_gs);
fprintf('%-22s  %-12.4f  %-12.4f  %-12.4f\n', 'Settling Time (s)',  stepinfo(G).SettlingTime, info_pid.SettlingTime,info_gs.SettlingTime);
fprintf('%-22s  %-12.2f  %-12.2f  %-12.2f\n', 'SS Error (%%)',      abs(1-y_ol(end))*100,     sse_pid,              sse_gs);
fprintf('=========================================\n');

%% --- Save Figure ---
if ~exist('results', 'dir'), mkdir('results'); end
saveas(gcf, 'results/comparison_plot.png');
fprintf('\nSaved: results/comparison_plot.png\n');
