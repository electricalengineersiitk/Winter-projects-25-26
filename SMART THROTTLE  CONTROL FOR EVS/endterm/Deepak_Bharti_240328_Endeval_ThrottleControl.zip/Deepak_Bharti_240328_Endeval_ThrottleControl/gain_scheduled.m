% gain_scheduled.m
% Phase 4: Gain-Scheduled PID controller for EV throttle
% Throttle zones: Zone1 (0-30%), Zone2 (30-70%), Zone3 (70-100%)
% Setpoint sequence: 20% → 50% → 85%  (one step per zone)

clear; clc; close all;

%% --- Plant ---
K   = 1;
tau = 0.5;
G   = tf(K, [tau 1]);

%% --- Zone PID Gains ---
% Zone 1 (0-30%): Low throttle — smooth, slow response
%   Higher Ki to overcome motor static friction / droop at low speed
%   Lower Kp to avoid jerky starts
zones(1).name = 'Zone 1 (0-30%)';
zones(1).Kp   = 1.5;
zones(1).Ki   = 3.0;
zones(1).Kd   = 0.02;

% Zone 2 (30-70%): Mid throttle — balanced, standard tuned PID
zones(2).name = 'Zone 2 (30-70%)';
zones(2).Kp   = 3.0;
zones(2).Ki   = 2.0;
zones(2).Kd   = 0.05;

% Zone 3 (70-100%): High throttle — fast, aggressive response
%   Higher Kp for rapid acceleration; lower Ki to prevent integrator windup
zones(3).name = 'Zone 3 (70-100%)';
zones(3).Kp   = 5.0;
zones(3).Ki   = 1.0;
zones(3).Kd   = 0.10;

%% --- Simulation Setup ---
% Each zone gets a 5-second simulation window
setpoints    = [0.20, 0.50, 0.85];   % normalised throttle positions
zone_indices = [1,    2,    3   ];
seg_time     = 5;                     % seconds per zone segment
t_seg        = 0:0.01:seg_time;

all_t = []; all_y = []; all_sp = [];
t_offset = 0;
transition_times = [];

fprintf('--- Gain-Scheduled Controller Simulation ---\n');
for i = 1:3
    z  = zones(zone_indices(i));
    sp = setpoints(i);

    C_z   = pid(z.Kp, z.Ki, z.Kd);
    T_z   = feedback(C_z * G, 1);

    % Step response scaled to setpoint magnitude, with IC from previous segment
    [y_z, ~] = step(sp * T_z, t_seg);

    % Smooth transition: blend starting point with previous end value
    if i > 1
        y_prev_end = all_y(end);
        % Linear ramp over first 10 samples to avoid discontinuity
        n_blend = min(10, length(y_z));
        blend   = linspace(0, 1, n_blend)';
        y_z(1:n_blend) = (1 - blend) * y_prev_end + blend * y_z(1:n_blend);
        transition_times(end+1) = t_offset; %#ok<SAGROW>
    end

    all_t  = [all_t;  t_seg' + t_offset]; %#ok<AGROW>
    all_y  = [all_y;  y_z              ]; %#ok<AGROW>
    all_sp = [all_sp; repmat(sp, length(t_seg), 1)]; %#ok<AGROW>
    t_offset = t_offset + seg_time;

    info = stepinfo(T_z);
    fprintf('\n  %s  |  Kp=%.1f Ki=%.1f Kd=%.2f\n', z.name, z.Kp, z.Ki, z.Kd);
    fprintf('    Setpoint      : %.0f%%\n', sp*100);
    fprintf('    Rise Time     : %.4f s\n', info.RiseTime);
    fprintf('    Overshoot     : %.2f %%\n', info.Overshoot);
    fprintf('    Settling Time : %.4f s\n', info.SettlingTime);
end

%% --- Plot ---
figure('Name','Gain-Scheduled Controller Response','NumberTitle','off');
yyaxis left
plot(all_t, all_y, 'b-', 'LineWidth', 2);
hold on;
stairs(all_t, all_sp, 'k--', 'LineWidth', 1.5);
ylabel('Motor Speed (normalised)', 'FontSize', 11);
ylim([0 1.1]);

% Mark zone transitions
colors = {'r','m'};
for j = 1:length(transition_times)
    xline(transition_times(j), '--', sprintf('Zone %d→%d', j, j+1), ...
        'Color', colors{j}, 'LineWidth', 1.5, 'LabelVerticalAlignment','top', ...
        'FontSize', 9);
end

% Zone labels
xregion(0,         seg_time,   'FaceColor', [0.8 0.9 1.0], 'FaceAlpha', 0.3);
xregion(seg_time,  2*seg_time, 'FaceColor', [0.8 1.0 0.8], 'FaceAlpha', 0.3);
xregion(2*seg_time,3*seg_time, 'FaceColor', [1.0 0.9 0.8], 'FaceAlpha', 0.3);

text(1.0,  0.05, 'Zone 1 (0-30%)',  'FontSize', 9, 'Color', [0.2 0.4 0.8]);
text(6.0,  0.05, 'Zone 2 (30-70%)', 'FontSize', 9, 'Color', [0.2 0.6 0.2]);
text(11.0, 0.05, 'Zone 3 (70-100%)','FontSize', 9, 'Color', [0.8 0.4 0.1]);

title('Gain-Scheduled Controller: Throttle Step Sequence (20% → 50% → 85%)', ...
    'FontSize', 13, 'FontWeight', 'bold');
xlabel('Time (seconds)', 'FontSize', 11);
legend('Motor Speed', 'Setpoint Reference', 'Location', 'southeast');
grid on; box on;

%% --- Save Figure ---
if ~exist('results', 'dir'), mkdir('results'); end
saveas(gcf, 'results/gainscheduled_response.png');
fprintf('\nSaved: results/gainscheduled_response.png\n');
