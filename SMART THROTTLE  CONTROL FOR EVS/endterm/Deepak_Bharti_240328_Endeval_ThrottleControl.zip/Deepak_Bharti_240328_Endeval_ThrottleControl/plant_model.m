% plant_model.m
% Phase 1: Define the throttle-motor transfer function and plot open-loop response
% Plant: G(s) = K / (tau*s + 1)  — first-order DC motor model

clear; clc; close all;

%% --- Plant Parameters ---
% K = steady-state gain: motor speed per unit throttle input (normalised to 1)
% tau = time constant: time to reach 63.2% of final speed = 0.5 s (typical small EV motor)
K   = 1;      % steady-state gain (normalised)
tau = 0.5;    % time constant (seconds)

%% --- Define Transfer Function ---
G = tf(K, [tau 1]);
fprintf('Plant Transfer Function:\n');
disp(G);

%% --- Open-Loop Step Response ---
t = 0:0.01:5;   % simulation time vector: 0 to 5 seconds
figure('Name','Open-Loop Step Response','NumberTitle','off');
[y, t_out] = step(G, t);
plot(t_out, y, 'b-', 'LineWidth', 2);
hold on;

% Mark 63.2% point to show time constant visually
yss = y(end);
idx = find(y >= 0.632 * yss, 1);
plot(t_out(idx), y(idx), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
yline(yss, 'k--', 'Steady State', 'LabelHorizontalAlignment','left');
xline(t_out(idx), 'r--', sprintf('\\tau = %.2f s', t_out(idx)), 'LabelVerticalAlignment','bottom');

title('Open-Loop Motor Step Response (No Controller)', 'FontSize', 13, 'FontWeight', 'bold');
xlabel('Time (seconds)', 'FontSize', 11);
ylabel('Motor Speed (normalised)', 'FontSize', 11);
legend('Open-Loop Response', '63.2% Point (\tau)', 'Location', 'southeast');
grid on; box on;

% Print key metrics
info = stepinfo(G);
fprintf('\n--- Open-Loop Step Response Metrics ---\n');
fprintf('  Steady-State Value : %.4f\n', yss);
fprintf('  Rise Time          : %.4f s\n', info.RiseTime);
fprintf('  Settling Time      : %.4f s\n', info.SettlingTime);
fprintf('  Overshoot          : %.2f %%\n', info.Overshoot);
fprintf('  Time Constant (tau): %.4f s\n', t_out(idx));

%% --- Save Figure ---
if ~exist('results', 'dir'), mkdir('results'); end
saveas(gcf, 'results/open_loop_response.png');
fprintf('\nSaved: results/open_loop_response.png\n');
