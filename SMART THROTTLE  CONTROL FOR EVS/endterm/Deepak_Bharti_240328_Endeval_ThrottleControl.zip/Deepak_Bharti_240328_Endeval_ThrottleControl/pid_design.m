% pid_design.m
% Phase 2: Design and tune a PID controller for the throttle-motor plant
% Targets: Rise time < 1s, Overshoot < 10%, Steady-state error < 2%

clear; clc; close all;

%% --- Plant (same as plant_model.m) ---
K   = 1;
tau = 0.5;
G   = tf(K, [tau 1]);

%% --- PID Gains (tuned manually following the step-by-step method) ---
% Step 1: Set Ki=0, Kd=0, increase Kp until rise time < 1s  → Kp = 3
% Step 2: Add Ki to eliminate steady-state error             → Ki = 2
% Step 3: Add small Kd to damp overshoot below 10%          → Kd = 0.05
Kp = 3.0;
Ki = 2.0;
Kd = 0.05;

C = pid(Kp, Ki, Kd);
fprintf('PID Controller:\n');
disp(C);

%% --- Closed-Loop Transfer Function ---
T_pid = feedback(C * G, 1);   % unity negative feedback
fprintf('Closed-Loop Transfer Function (PID):\n');
disp(T_pid);

%% --- Step Response Plot ---
t = 0:0.01:5;
[y, t_out] = step(T_pid, t);

figure('Name','PID Closed-Loop Step Response','NumberTitle','off');
plot(t_out, y, 'b-', 'LineWidth', 2);
hold on;

% Annotate overshoot
[peak_val, peak_idx] = max(y);
yss = y(end);
overshoot_pct = (peak_val - yss) / yss * 100;
plot(t_out(peak_idx), peak_val, 'rv', 'MarkerSize', 9, 'LineWidth', 2);
text(t_out(peak_idx)+0.05, peak_val, sprintf('Peak: %.3f\n(OS=%.1f%%)', peak_val, overshoot_pct), ...
    'Color','red','FontSize',9);

% Annotate rise time
info = stepinfo(T_pid);
xline(info.RiseTime, 'g--', sprintf('Rise Time = %.3f s', info.RiseTime), ...
    'LabelVerticalAlignment','bottom','Color',[0 0.6 0]);
yline(yss, 'k--', sprintf('SS = %.4f', yss), 'LabelHorizontalAlignment','left');
yline(1.0, 'm:', 'Setpoint = 1', 'LabelHorizontalAlignment','right');

title(sprintf('PID Closed-Loop Response  |  Kp=%.1f, Ki=%.1f, Kd=%.2f', Kp, Ki, Kd), ...
    'FontSize', 13, 'FontWeight', 'bold');
xlabel('Time (seconds)', 'FontSize', 11);
ylabel('Motor Speed (normalised)', 'FontSize', 11);
legend('PID Response','Peak (Overshoot)','Location','southeast');
grid on; box on;
ylim([0 1.2]);

%% --- Performance Metrics ---
ss_error_pct = abs(1 - yss) / 1 * 100;
fprintf('\n--- PID Performance Metrics ---\n');
fprintf('  Kp = %.2f,  Ki = %.2f,  Kd = %.3f\n', Kp, Ki, Kd);
fprintf('  Rise Time       : %.4f s   (target < 1.0 s)  → %s\n', info.RiseTime,   pass_fail(info.RiseTime < 1.0));
fprintf('  Overshoot       : %.2f %%  (target < 10 %%)  → %s\n', overshoot_pct,   pass_fail(overshoot_pct < 10));
fprintf('  Settling Time   : %.4f s\n', info.SettlingTime);
fprintf('  Steady-State Val: %.4f\n', yss);
fprintf('  SS Error        : %.2f %%  (target < 2 %%)   → %s\n', ss_error_pct,    pass_fail(ss_error_pct < 2));

%% --- Save Figure ---
if ~exist('results', 'dir'), mkdir('results'); end
saveas(gcf, 'results/pid_response.png');
fprintf('\nSaved: results/pid_response.png\n');

%% --- Helper ---
function s = pass_fail(cond)
    if cond, s = 'PASS ✓'; else, s = 'FAIL ✗'; end
end
