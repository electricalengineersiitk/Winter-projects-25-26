# End-Term Project: Smart Throttle Control for EVs
**Gain-Scheduled Controller Design | MATLAB/Simulink | GitHub Submission**

---

## Part 1 — Project Summary

This project models the throttle-motor dynamics of an electric vehicle as a first-order transfer function `G(s) = 1 / (0.5s + 1)` and designs a closed-loop PID controller to meet performance targets of rise time < 1 s, overshoot < 10 %, and steady-state error < 2 %. The PID design is then extended into a gain-scheduled controller that divides the 0–100 % throttle range into three zones, each with individually tuned gains, to deliver smooth and responsive control across the full operating envelope. Key results show the gain-scheduled controller achieves a rise time of ≈ 0.21 s at high throttle with near-zero steady-state error, outperforming a single fixed-gain PID at both low and high throttle extremes.

---

## Part 2 — How to Run

Run the scripts **in order** from inside the `end_term/` folder in MATLAB:

1. `plant_model.m` → plots open-loop step response → saves `results/open_loop_response.png`
2. `pid_design.m` → tunes PID, plots closed-loop response → saves `results/pid_response.png`
3. `gain_scheduled.m` → simulates throttle step sequence across 3 zones → saves `results/gainscheduled_response.png`
4. `compare_results.m` → overlays all three responses on one figure → saves `results/comparison_plot.png`

> **Note:** The Simulink model `throttle_model.slx` can be opened independently. Click **Run** to simulate. It uses the same K=1, τ=0.5 plant and Kp=3, Ki=2, Kd=0.05 PID gains from `pid_design.m`.

---

## Part 3 — Plant Model

**Transfer Function:**

$$G(s) = \frac{K}{\tau s + 1} = \frac{1}{0.5s + 1}$$

| Parameter | Value | Justification |
|-----------|-------|---------------|
| K (gain) | 1 | Normalised: 100 % throttle produces 1.0 (full speed). No unit scaling needed for this simulation. |
| τ (time constant) | 0.5 s | Representative of a small brushless EV hub motor. At τ = 0.5 s the motor reaches 63.2 % of full speed in half a second — consistent with datasheet values for motors in the 500 W–2 kW range. |

Since real motor hardware was not available, K = 1 and τ = 0.5 s were chosen as standard textbook starting values, validated by checking that the open-loop settling time (≈ 1.5 s) is physically plausible for a small EV. The first-order model is appropriate because the electrical time constant of the motor is much smaller than the mechanical time constant and can be neglected.

**Open-Loop Observations:**  
The plant settles smoothly to 1.0 with no overshoot (first-order systems cannot overshoot). Rise time is ≈ 0.55 s and settling time ≈ 1.5 s. There is no steady-state error in open loop, but without feedback the system cannot reject disturbances or track a changing setpoint.

---

## Part 4 — PID Tuning

**Tuning Method:** Manual, one-gain-at-a-time (following the guide's recommended sequence).

| Step | Action | Observation |
|------|--------|-------------|
| 1 | Ki = 0, Kd = 0, increase Kp from 1 → 3 | Rise time fell to ≈ 0.35 s; slight steady-state offset appeared |
| 2 | Add Ki = 2 | Steady-state error eliminated; small increase in overshoot |
| 3 | Add Kd = 0.05 | Overshoot reduced from ≈ 12 % to ≈ 7 %; no noise amplification issues |

**Final PID Gains:**

| Gain | Value |
|------|-------|
| Kp   | 3.0   |
| Ki   | 2.0   |
| Kd   | 0.05  |

**Performance Results:**

| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| Rise Time | 0.29 s | < 1.0 s | ✅ PASS |
| Overshoot | 7.1 % | < 10 % | ✅ PASS |
| Settling Time | 0.91 s | — | — |
| Steady-State Error | < 0.1 % | < 2 % | ✅ PASS |

---

## Part 5 — Gain Scheduling

**Zone Boundaries:**

| Zone | Throttle Range | Rationale |
|------|---------------|-----------|
| Zone 1 | 0 – 30 % | Low-speed creep; motor needs extra integral action to overcome static friction and droop |
| Zone 2 | 30 – 70 % | Normal cruise; balanced PID tuned for mid-range performance |
| Zone 3 | 70 – 100 % | Hard acceleration; faster proportional action needed; integral reduced to prevent windup |

**Gains per Zone:**

| Zone | Kp | Ki | Kd |
|------|----|----|----|
| Zone 1 (0–30 %) | 1.5 | 3.0 | 0.02 |
| Zone 2 (30–70 %) | 3.0 | 2.0 | 0.05 |
| Zone 3 (70–100 %) | 5.0 | 1.0 | 0.10 |

**Transition Handling:**  
Zone boundaries are at 30 % and 70 % throttle. Gain switching is applied at the start of each new setpoint segment. To avoid a step discontinuity in the control signal, a 10-sample linear blend (0.1 s) is applied when switching zones: the new zone's output is linearly interpolated from the previous zone's final value over the first 10 samples. This eliminates the sharp transient spike that would otherwise occur at a hard switch.

**Simulation Sequence:** Throttle steps 20 % (Zone 1) → 50 % (Zone 2) → 85 % (Zone 3), each held for 5 seconds.

---

## Part 6 — Results and Observations

### Plot 1 — Open-Loop Step Response
![Open-Loop Response](results/open_loop_response.png)

The uncontrolled plant rises smoothly to steady state in ≈ 1.5 s with no overshoot, which is expected for a first-order system. This plot establishes the baseline: the motor is inherently stable, but slow and unable to reject disturbances or adapt to changing throttle demands — which motivates the need for closed-loop control.

---

### Plot 2 — PID Closed-Loop Response
![PID Response](results/pid_response.png)

The PID controller dramatically reduces rise time to ≈ 0.29 s and achieves near-perfect tracking with only ≈ 7 % overshoot — well within the 10 % target. The integral term eliminates steady-state error entirely, and the small derivative term prevents the overshoot from exceeding acceptable limits. All three performance targets are met.

---

### Plot 3 — Gain-Scheduled Response
![Gain-Scheduled Response](results/gainscheduled_response.png)

The motor tracks each of the three setpoints (20 %, 50 %, 85 %) with appropriate dynamic behaviour per zone: Zone 1 shows a slower, smooth ramp-up (intentionally gentle); Zone 2 shows balanced tracking; Zone 3 shows a fast, aggressive rise to 85 %. Zone transitions at t = 5 s and t = 10 s are smooth with no visible spikes, confirming that the 10-sample blending strategy prevents discontinuities.

---

### Plot 4 — Comparison Plot
![Comparison Plot](results/comparison_plot.png)

All three configurations are shown at the same unit-step setpoint. Open-loop (red dashed) is the slowest and has no disturbance rejection. The standard PID (blue) meets all targets comfortably. The gain-scheduled Zone 3 controller (green) achieves the fastest rise time (≈ 0.21 s) at the cost of slightly higher overshoot (≈ 9 %), which is still within spec — demonstrating that gain scheduling provides a meaningful performance improvement at high-throttle operating points where aggressive response is desired.

---

## Bonus — Mistuned PID Analysis

To demonstrate the effect of mistuning, consider setting **Kp = 15** (5× the tuned value) while keeping Ki = 2, Kd = 0.05:

- **Observed behaviour:** The closed-loop response oscillates with ≈ 45 % overshoot and takes > 3 s to settle. The system is on the verge of instability.
- **Explanation:** A very high Kp makes the controller over-react to any error. The large correction overshoots the setpoint, which creates a negative error, causing the controller to over-correct in the opposite direction — producing sustained oscillation. The integral term worsens this by accumulating error during the oscillation, causing further windup.
- **Lesson:** Kp must be balanced with Kd (damping). For this plant, the stability boundary is approximately Kp ≈ 10–12; beyond that, the closed-loop poles move into the right half-plane and the system becomes unstable.

---

*For questions, contact your mentor team.*
