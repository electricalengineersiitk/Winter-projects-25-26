# Smart Multimeter — Simulation & Design

## Part 1 — What did you build?

This project simulates an industry-grade digital multimeter capable of measuring **Resistance (R)**, **Capacitance (C)**, and **Inductance (L)** across a 10⁵ dynamic range. The auto-ranging engine automatically selects the correct measurement scale (1 of 5 ranges) without user input, using a hysteresis rule that requires 3 consecutive out-of-range readings before committing to a range switch. The simulation achieves an average accuracy of **≈98%** across all three measurement modes (average error: R = 0.48%, C = 0.35%, L = 0.91%).

---

## Part 2 — How to set it up

```bash
git clone https://github.com/your-username/your-repo.git
cd your-repo/end_term/smart_multimeter
pip install -r requirements.txt
```

> **Requirements:** Python 3.10+, numpy ≥ 1.24.0, matplotlib ≥ 3.7.0

---

## Part 3 — How to run the simulation

```bash
python simulate.py
```

The script generates 50 log-spaced test values spanning all 5 ranges for each mode (R: 100 Ω → 1 MΩ, C: 10 nF → 100 µF, L: 10 µH → 100 mH), passes each through the measurement model with 0.5% Gaussian ADC noise, then routes the result through the auto-ranging engine. It prints a full per-sample results table for each mode, a summary comparison table, and saves both plots to `results/`.

---

## Part 4 — Your results

Simulation run with `numpy.random.seed(42)` for reproducibility:

| **Method**                  | **R Error** | **C Error** | **L Error** |
|-----------------------------|-------------|-------------|-------------|
| Fixed-range (no auto)       | 25.44%      | 25.26%      | 25.58%      |
| **Auto-ranging (this sim)** | **0.48%**   | **0.35%**   | **0.91%**   |

The auto-ranging engine reduces average error by ~98% compared to the fixed mid-range baseline.

### Accuracy Plots

![Accuracy vs Input Value](results/plot_accuracy.png)

*Plot 1: Auto-ranging consistently achieves <2% error across the full 10⁵ range; fixed-range baseline degrades sharply at range boundaries.*

![Auto-Range State Over Time](results/plot_autorange.png)

*Plot 2: Range steps up and down cleanly as input sweeps from minimum to maximum, demonstrating correct auto-ranging behaviour.*

---

## Part 5 — Known limitations

In real hardware, several factors would increase measurement error beyond the simulated 0.5% ADC noise. An actual ADC would introduce quantisation error, non-linearity, and offset drift that vary with temperature — typically requiring factory calibration coefficients stored in EEPROM. Op-amp input offset voltage (~1 mV) and bias current would create systematic offsets in the voltage divider and RC timing circuits, especially at high impedance values. Probe resistance (0.1–1 Ω) and lead inductance would add significant error at the lower end of the R and L ranges. The LC resonance method for inductance also assumes an ideal capacitor, whereas a real C_ref would have parasitic ESR and a tolerance of ±1–5%, directly flowing into the L calculation.

---

## Project Structure

```
end_term/
└── smart_multimeter/
    ├── README.md              ← this file
    ├── requirements.txt       ← numpy, matplotlib
    ├── simulate.py            ← main entry point (run this)
    ├── autorange.py           ← auto-ranging engine with hysteresis
    ├── measurement.py         ← R, C, L formulas + noise model
    ├── protocol.py            ← OTG serial packet format (BONUS)
    ├── docs/
    │   └── app_wireframe.png  ← mobile app block diagram (BONUS)
    └── results/
        ├── plot_accuracy.png
        └── plot_autorange.png
```

---

## Bonus — OTG Serial Protocol

See [`protocol.py`](protocol.py) for the full packet specification.

- **Packet size:** 12 bytes
- **Baud rate:** 115200
- **Format:** `[0xAA][MODE][RANGE][VALUE_float32][ERROR_uint16][STATUS][XOR_CHECKSUM][0x55]`
- Run `python protocol.py` to see encode/decode self-test output.

---

*Start with `python measurement.py` to verify formulas, then `python autorange.py` to test ranging, then `python simulate.py` for the full run.*
