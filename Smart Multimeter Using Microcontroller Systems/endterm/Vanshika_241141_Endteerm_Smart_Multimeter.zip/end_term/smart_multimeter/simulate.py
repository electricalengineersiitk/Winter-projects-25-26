"""
simulate.py — Main simulation entry point
Smart Multimeter Simulation

Runs 50-sample sweep across all 5 ranges for R, C, and L modes.
Compares auto-ranging engine vs fixed-range baseline.
Generates both required plots in results/.
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from measurement import measure_resistance, measure_capacitance, measure_inductance
from autorange import AutoRanger, get_ideal_range, RANGES

# Output directory
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

NUM_SAMPLES = 50  # samples per mode


def fixed_range_error(mode: str, true_val: float) -> float:
    """Simulate fixed-range (no auto) error by always using Range 3 (mid-range)."""
    fixed_range_max = RANGES[mode][2][1]  # Range 3 max
    measure_fn = {"R": measure_resistance, "C": measure_capacitance, "L": measure_inductance}[mode]
    measured, _ = measure_fn(true_val)
    # If value is outside fixed range, error is large (saturation / underflow)
    if true_val > fixed_range_max * 10 or true_val < fixed_range_max / 100:
        # Simulate out-of-range reading — clamp to range max → large error
        clamped = fixed_range_max if true_val > fixed_range_max else fixed_range_max * 0.01
        return abs(clamped - true_val) / true_val * 100
    return _


def run_simulation(mode: str, true_values: np.ndarray, measure_fn) -> dict:
    """
    Run simulation for one mode.
    Returns dict with per-sample results.
    """
    ranger = AutoRanger(mode)
    ranger.reset()

    results = {
        "true_values": [],
        "measured_values": [],
        "auto_errors": [],
        "fixed_errors": [],
        "range_indices": [],
        "statuses": [],
    }

    for true_val in true_values:
        measured, error_pct = measure_fn(true_val)
        ar = ranger.update(measured)
        fixed_err = fixed_range_error(mode, true_val)

        results["true_values"].append(true_val)
        results["measured_values"].append(measured)
        results["auto_errors"].append(error_pct)
        results["fixed_errors"].append(min(fixed_err, 100.0))  # cap display at 100%
        results["range_indices"].append(ar["range_idx"] + 1)   # 1-indexed for plot
        results["statuses"].append(ar["status"])

    return results


def print_results_table(mode: str, results: dict, unit: str):
    """Print a formatted results table for one mode."""
    true_vals = results["true_values"]
    measured_vals = results["measured_values"]
    auto_errs = results["auto_errors"]
    range_idxs = results["range_indices"]

    print(f"\n{'─'*72}")
    print(f"  Mode: {mode} ({unit})")
    print(f"{'─'*72}")
    print(f"  {'True Value':>14}  {'Measured':>14}  {'Auto Error':>12}  {'Range':>7}")
    print(f"  {'─'*14}  {'─'*14}  {'─'*12}  {'─'*7}")

    for i in range(len(true_vals)):
        print(f"  {true_vals[i]:>14.4g}  {measured_vals[i]:>14.4g}  "
              f"{auto_errs[i]:>11.3f}%  {'R'+str(range_idxs[i]):>7}")

    avg_auto = np.mean(auto_errs)
    avg_fixed = np.mean(results["fixed_errors"])
    print(f"\n  ▶  Average auto-ranging error : {avg_auto:.3f}%")
    print(f"  ▶  Average fixed-range error  : {avg_fixed:.3f}%")
    print(f"{'─'*72}")
    return avg_auto, avg_fixed


def make_accuracy_plot(all_results: dict):
    """Plot 1 — Accuracy vs Input Value (log scale)."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle("Plot 1: Measurement Accuracy vs Input Value\n(Auto-Ranging vs Fixed-Range Baseline)",
                 fontsize=13, fontweight="bold")

    configs = [
        ("R", "Resistance (Ω)", "tab:blue"),
        ("C", "Capacitance (F)", "tab:green"),
        ("L", "Inductance (H)", "tab:orange"),
    ]

    for ax, (mode, xlabel, color) in zip(axes, configs):
        res = all_results[mode]
        tv = res["true_values"]
        ax.plot(tv, res["auto_errors"], "o-", color=color, linewidth=1.5,
                markersize=4, label="Auto-ranging (this sim)")
        ax.plot(tv, res["fixed_errors"], "s--", color="gray", linewidth=1.2,
                markersize=4, alpha=0.7, label="Fixed-range baseline")
        ax.set_xscale("log")
        ax.set_xlabel(xlabel, fontsize=10)
        ax.set_ylabel("% Measurement Error", fontsize=10)
        ax.set_title(f"{mode} Mode", fontsize=11)
        ax.legend(fontsize=8)
        ax.grid(True, which="both", linestyle="--", alpha=0.4)
        ax.set_ylim(bottom=0)

    plt.tight_layout()
    out_path = os.path.join(RESULTS_DIR, "plot_accuracy.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\n  [✓] Saved: {out_path}")


def make_autorange_plot(all_results: dict):
    """Plot 2 — Auto-Range State Over Time."""
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    fig.suptitle("Plot 2: Auto-Range State Over Time\n(Range Steps as Input Sweeps Full Scale)",
                 fontsize=13, fontweight="bold")

    configs = [
        ("R", "Resistance Mode", "tab:blue"),
        ("C", "Capacitance Mode", "tab:green"),
        ("L", "Inductance Mode", "tab:orange"),
    ]

    sample_idx = np.arange(1, NUM_SAMPLES + 1)
    for ax, (mode, title, color) in zip(axes, configs):
        ri = all_results[mode]["range_indices"]
        ax.step(sample_idx, ri, where="post", color=color, linewidth=2)
        ax.fill_between(sample_idx, ri, step="post", alpha=0.15, color=color)
        ax.set_ylabel("Active Range (1–5)", fontsize=10)
        ax.set_title(title, fontsize=11)
        ax.set_yticks([1, 2, 3, 4, 5])
        ax.set_ylim(0.5, 5.5)
        ax.grid(True, axis="y", linestyle="--", alpha=0.4)
        ax.grid(True, axis="x", linestyle=":", alpha=0.3)

    axes[-1].set_xlabel("Test Sample Index (1 to 50)", fontsize=10)
    plt.tight_layout()
    out_path = os.path.join(RESULTS_DIR, "plot_autorange.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [✓] Saved: {out_path}")


def main():
    np.random.seed(42)  # reproducibility

    print("\n" + "═"*72)
    print("  SMART MULTIMETER SIMULATION")
    print("  Auto-ranging R / C / L  |  50-sample sweep  |  5 ranges each")
    print("═"*72)

    # ── Generate 50 log-spaced test values across all 5 ranges ──
    r_values  = np.logspace(2, 6, NUM_SAMPLES)       # 100 Ω  → 1 MΩ
    c_values  = np.logspace(-8, -4, NUM_SAMPLES)     # 10 nF  → 100 µF
    l_values  = np.logspace(-5, -1, NUM_SAMPLES)     # 10 µH  → 100 mH

    # ── Run simulations ──
    all_results = {}
    all_results["R"] = run_simulation("R", r_values,  measure_resistance)
    all_results["C"] = run_simulation("C", c_values,  measure_capacitance)
    all_results["L"] = run_simulation("L", l_values,  measure_inductance)

    # ── Print results tables ──
    avg_r_auto, avg_r_fixed = print_results_table("R", all_results["R"], "Ohms")
    avg_c_auto, avg_c_fixed = print_results_table("C", all_results["C"], "Farads")
    avg_l_auto, avg_l_fixed = print_results_table("L", all_results["L"], "Henries")

    # ── Summary comparison table ──
    print("\n" + "═"*72)
    print("  SUMMARY — Auto-Ranging vs Fixed-Range Baseline")
    print("═"*72)
    print(f"  {'Method':<30}  {'R Error':>9}  {'C Error':>9}  {'L Error':>9}")
    print(f"  {'─'*30}  {'─'*9}  {'─'*9}  {'─'*9}")
    print(f"  {'Fixed-range (no auto)':<30}  {avg_r_fixed:>8.2f}%  {avg_c_fixed:>8.2f}%  {avg_l_fixed:>8.2f}%")
    print(f"  {'Auto-ranging (this sim)':<30}  {avg_r_auto:>8.2f}%  {avg_c_auto:>8.2f}%  {avg_l_auto:>8.2f}%")
    print("═"*72)

    # ── Status check ──
    passed = all(e <= 2.0 for e in [avg_r_auto, avg_c_auto, avg_l_auto])
    status = "✓ PASS" if passed else "✗ FAIL"
    print(f"\n  Average error ≤ 2% check: {status}")

    # ── Generate plots ──
    print("\n  Generating plots...")
    make_accuracy_plot(all_results)
    make_autorange_plot(all_results)

    print("\n  Simulation complete.\n")


if __name__ == "__main__":
    main()
