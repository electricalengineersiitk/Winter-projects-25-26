"""
protocol.py — OTG Serial Packet Format
Smart Multimeter Simulation

Defines the packet structure for transmitting multimeter readings
over a USB OTG serial connection to a mobile app.

Packet format (16 bytes total):
  [START_BYTE][MODE][RANGE][VALUE_4B][ERROR_2B][STATUS][CHECKSUM][END_BYTE]

  Byte 0    : START_BYTE    = 0xAA
  Byte 1    : MODE          = 0x01 (R) | 0x02 (C) | 0x03 (L)
  Byte 2    : RANGE         = 1–5
  Bytes 3–6 : VALUE         = float32 (big-endian), measured value
  Bytes 7–8 : ERROR         = uint16 (big-endian), error × 100 (e.g. 125 = 1.25%)
  Byte 9    : STATUS        = 0x00 SETTLED | 0x01 RANGING_UP |
                              0x02 RANGING_DOWN | 0xFF OL
  Byte 10   : CHECKSUM      = XOR of bytes 1–9
  Byte 11   : END_BYTE      = 0x55

Total: 12 bytes per packet.
Baud rate: 115200
"""

import struct

# Packet constants
START_BYTE  = 0xAA
END_BYTE    = 0x55

# Mode codes
MODE_R = 0x01
MODE_C = 0x02
MODE_L = 0x03

# Status codes
STATUS_SETTLED     = 0x00
STATUS_RANGING_UP  = 0x01
STATUS_RANGING_DOWN = 0x02
STATUS_OL          = 0xFF

MODE_MAP = {"R": MODE_R, "C": MODE_C, "L": MODE_L}
STATUS_MAP = {
    "SETTLED":      STATUS_SETTLED,
    "RANGING_UP":   STATUS_RANGING_UP,
    "RANGING_DOWN": STATUS_RANGING_DOWN,
    "OL":           STATUS_OL,
}


def encode_packet(mode: str, range_idx: int, value: float,
                  error_pct: float, status: str) -> bytes:
    """
    Encode a measurement result into a 12-byte OTG serial packet.

    Args:
        mode      : 'R', 'C', or 'L'
        range_idx : Active range index (1–5)
        value     : Measured value (float)
        error_pct : Measurement error in percent (float)
        status    : One of SETTLED, RANGING_UP, RANGING_DOWN, OL

    Returns:
        12-byte packet as bytes object
    """
    mode_byte   = MODE_MAP.get(mode, 0x00)
    range_byte  = max(1, min(5, range_idx)) & 0xFF
    value_bytes = struct.pack(">f", float(value))   # 4 bytes, big-endian float32
    error_int   = int(round(error_pct * 100))       # e.g. 1.25% → 125
    error_bytes = struct.pack(">H", min(error_int, 65535))  # 2 bytes uint16
    status_byte = STATUS_MAP.get(status, STATUS_SETTLED)

    # Build payload (bytes 1–9) for checksum calculation
    payload = bytes([mode_byte, range_byte]) + value_bytes + error_bytes + bytes([status_byte])

    # XOR checksum over payload
    checksum = 0
    for b in payload:
        checksum ^= b

    packet = bytes([START_BYTE]) + payload + bytes([checksum, END_BYTE])
    return packet


def decode_packet(packet: bytes) -> dict | None:
    """
    Decode a 12-byte OTG serial packet.

    Returns:
        dict with decoded fields, or None if packet is invalid.
    """
    if len(packet) != 12:
        return None
    if packet[0] != START_BYTE or packet[11] != END_BYTE:
        return None

    # Verify checksum
    checksum = 0
    for b in packet[1:10]:
        checksum ^= b
    if checksum != packet[10]:
        return None

    mode_byte   = packet[1]
    range_byte  = packet[2]
    value       = struct.unpack(">f", packet[3:7])[0]
    error_pct   = struct.unpack(">H", packet[7:9])[0] / 100.0
    status_byte = packet[9]

    mode_rev   = {v: k for k, v in MODE_MAP.items()}
    status_rev = {v: k for k, v in STATUS_MAP.items()}

    return {
        "mode":      mode_rev.get(mode_byte, "?"),
        "range":     range_byte,
        "value":     value,
        "error_pct": error_pct,
        "status":    status_rev.get(status_byte, "UNKNOWN"),
    }


def format_packet_hex(packet: bytes) -> str:
    """Return a human-readable hex dump of a packet."""
    return " ".join(f"{b:02X}" for b in packet)


if __name__ == "__main__":
    print("=== protocol.py self-test ===\n")

    test_cases = [
        ("R", 3, 4700.0,  0.42, "SETTLED"),
        ("C", 2, 82e-9,   0.71, "RANGING_UP"),
        ("L", 4, 8.2e-3,  1.05, "SETTLED"),
        ("R", 5, 999999.0, 0.0, "OL"),
    ]

    for mode, rng, val, err, status in test_cases:
        pkt = encode_packet(mode, rng, val, err, status)
        decoded = decode_packet(pkt)
        print(f"  Encode → {format_packet_hex(pkt)}")
        print(f"  Decode → mode={decoded['mode']}  range={decoded['range']}  "
              f"value={decoded['value']:.4g}  error={decoded['error_pct']:.2f}%  "
              f"status={decoded['status']}")
        print()

    print(f"  Packet size: {len(encode_packet('R', 1, 100.0, 0.5, 'SETTLED'))} bytes")
    print("  Baud rate  : 115200")
    print("  Interface  : USB OTG (CDC ACM virtual serial port)")
