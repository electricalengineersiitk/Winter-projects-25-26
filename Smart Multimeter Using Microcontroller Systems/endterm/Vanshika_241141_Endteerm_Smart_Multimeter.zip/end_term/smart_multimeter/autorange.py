"""
autorange.py — Auto-ranging engine
Smart Multimeter Simulation

Supports R, C, L modes with 5 ranges each.
Hysteresis: requires 3 consecutive out-of-range readings before switching.
"""


# Range definitions for each mode
# Format: (label, max_value)
RANGES = {
    "R": [
        ("Range 1", 100),          # 100 Ω
        ("Range 2", 1_000),        # 1 kΩ
        ("Range 3", 10_000),       # 10 kΩ
        ("Range 4", 100_000),      # 100 kΩ
        ("Range 5", 1_000_000),    # 1 MΩ
    ],
    "C": [
        ("Range 1", 10e-9),        # 10 nF
        ("Range 2", 100e-9),       # 100 nF
        ("Range 3", 1e-6),         # 1 µF
        ("Range 4", 10e-6),        # 10 µF
        ("Range 5", 100e-6),       # 100 µF
    ],
    "L": [
        ("Range 1", 10e-6),        # 10 µH
        ("Range 2", 100e-6),       # 100 µH
        ("Range 3", 1e-3),         # 1 mH
        ("Range 4", 10e-3),        # 10 mH
        ("Range 5", 100e-3),       # 100 mH
    ],
}

STEP_UP_THRESHOLD = 0.90    # 90% of range max → step up
STEP_DOWN_THRESHOLD = 0.10  # 10% of range max → step down
HYSTERESIS_COUNT = 3        # consecutive triggers required before switching


class AutoRanger:
    """
    Stateful auto-ranging engine.
    Call .update(reading) on each new measurement.
    """

    def __init__(self, mode: str):
        if mode not in RANGES:
            raise ValueError(f"Mode must be one of {list(RANGES.keys())}")
        self.mode = mode
        self.ranges = RANGES[mode]
        self.current_range_idx = 0
        self._up_count = 0
        self._down_count = 0

    def reset(self):
        """Reset ranger to initial state."""
        self.current_range_idx = 0
        self._up_count = 0
        self._down_count = 0

    def update(self, reading: float) -> dict:
        """
        Process a new reading and determine the correct range.

        Args:
            reading: Raw measured value (same units as ranges)

        Returns:
            dict with keys:
              - 'range_idx'   : 0-based index of active range (0–4)
              - 'range_label' : e.g. "Range 3"
              - 'range_max'   : max value of active range
              - 'status'      : 'SETTLED', 'RANGING_UP', 'RANGING_DOWN', 'OL'
              - 'value'       : reading (or None if OL)
        """
        num_ranges = len(self.ranges)
        label, range_max = self.ranges[self.current_range_idx]

        # Overload check — exceeds all ranges
        if reading > self.ranges[-1][1]:
            self._up_count = 0
            self._down_count = 0
            return {
                "range_idx": self.current_range_idx,
                "range_label": label,
                "range_max": range_max,
                "status": "OL",
                "value": None,
            }

        up_thresh = STEP_UP_THRESHOLD * range_max
        down_thresh = STEP_DOWN_THRESHOLD * range_max

        # Step UP check
        if reading > up_thresh and self.current_range_idx < num_ranges - 1:
            self._up_count += 1
            self._down_count = 0
            if self._up_count >= HYSTERESIS_COUNT:
                self.current_range_idx += 1
                self._up_count = 0
                label, range_max = self.ranges[self.current_range_idx]
            return {
                "range_idx": self.current_range_idx,
                "range_label": label,
                "range_max": range_max,
                "status": "RANGING_UP",
                "value": reading,
            }

        # Step DOWN check
        elif reading < down_thresh and self.current_range_idx > 0:
            self._down_count += 1
            self._up_count = 0
            if self._down_count >= HYSTERESIS_COUNT:
                self.current_range_idx -= 1
                self._down_count = 0
                label, range_max = self.ranges[self.current_range_idx]
            return {
                "range_idx": self.current_range_idx,
                "range_label": label,
                "range_max": range_max,
                "status": "RANGING_DOWN",
                "value": reading,
            }

        # SETTLED
        else:
            self._up_count = 0
            self._down_count = 0
            return {
                "range_idx": self.current_range_idx,
                "range_label": label,
                "range_max": range_max,
                "status": "SETTLED",
                "value": reading,
            }


def get_ideal_range(mode: str, value: float) -> int:
    """Return the ideal 0-based range index for a given value (for baseline comparison)."""
    for i, (_, max_val) in enumerate(RANGES[mode]):
        if value <= max_val:
            return i
    return len(RANGES[mode]) - 1


if __name__ == "__main__":
    print("=== autorange.py self-test ===\n")
    import numpy as np

    ranger = AutoRanger("R")
    test_values = list(np.logspace(2, 6, 30))  # 100 Ω to 1 MΩ

    print(f"{'True Value':>14}  {'Range':>8}  {'Status':>14}")
    print("-" * 42)
    for v in test_values:
        result = ranger.update(v)
        print(f"{v:>14.1f}  {result['range_label']:>8}  {result['status']:>14}")
