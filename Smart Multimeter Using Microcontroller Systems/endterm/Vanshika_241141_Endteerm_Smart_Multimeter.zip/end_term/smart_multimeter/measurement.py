"""
measurement.py — R, C, L formulas + noise model
Smart Multimeter Simulation
"""

import numpy as np


# Constants
V_REF = 5.0        # Reference voltage (V)
V_SUPPLY = 5.0     # Supply voltage for RC timing (V)
C_REF = 1e-6       # Reference capacitor for LC resonance (1 µF)
NOISE_SIGMA = 0.005  # 0.5% of true value

# Adaptive R_ref lookup — matched to resistance range for best divider ratio
# Using a reference resistor close to the measured value minimises ADC error
R_REF_TABLE = [
    (100,      100.0),       # Range 1: 100 Ω ref
    (1_000,    1_000.0),     # Range 2: 1 kΩ ref
    (10_000,   10_000.0),    # Range 3: 10 kΩ ref
    (100_000,  100_000.0),   # Range 4: 100 kΩ ref
    (1_000_000, 1_000_000.0),# Range 5: 1 MΩ ref
]

def _get_r_ref(true_r: float) -> float:
    """Return the best R_ref for the given resistance magnitude."""
    for max_val, r_ref in R_REF_TABLE:
        if true_r <= max_val * 1.2:
            return r_ref
    return R_REF_TABLE[-1][1]

R_REF = 10000.0    # Default (used by C measurement for RC timing)


def add_noise(true_val: float) -> float:
    """Add Gaussian noise (σ = 0.5% of true value) to simulate ADC imprecision."""
    return np.random.normal(true_val, NOISE_SIGMA * abs(true_val))


def measure_resistance(true_r: float) -> tuple[float, float]:
    """
    Measure resistance using the voltage divider method.
    R = R_ref x V_adc / (V_ref - V_adc)
    Uses adaptive R_ref matched to resistance range for best ADC resolution.

    Args:
        true_r: True resistance value in Ohms
    Returns:
        (measured_value, error_percent)
    """
    r_ref = _get_r_ref(true_r)
    # True V_adc from voltage divider
    v_adc_true = V_REF * true_r / (r_ref + true_r)
    v_adc_noisy = add_noise(v_adc_true)
    v_adc_noisy = np.clip(v_adc_noisy, 1e-6, V_REF - 1e-6)
    measured_r = r_ref * v_adc_noisy / (V_REF - v_adc_noisy)
    error_pct = abs(measured_r - true_r) / true_r * 100
    return measured_r, error_pct


def measure_capacitance(true_c: float) -> tuple[float, float]:
    """
    Measure capacitance using RC charge-discharge timing.
    C = t / R_ref  (t = time for V to reach 63.2% of V_supply)

    Args:
        true_c: True capacitance in Farads
    Returns:
        (measured_value, error_percent)
    """
    # True time constant: tau = R_ref * C
    tau_true = R_REF * true_c

    # Add noise to the time measurement
    tau_noisy = add_noise(tau_true)
    tau_noisy = max(tau_noisy, 1e-15)  # prevent negative time

    # Derive C from time constant
    measured_c = tau_noisy / R_REF

    error_pct = abs(measured_c - true_c) / true_c * 100
    return measured_c, error_pct


def measure_inductance(true_l: float) -> tuple[float, float]:
    """
    Measure inductance using LC resonance frequency method.
    L = 1 / ((2πf)² × C_ref)  where f = measured resonant frequency

    Args:
        true_l: True inductance in Henries
    Returns:
        (measured_value, error_percent)
    """
    # True resonant frequency: f = 1 / (2π √(LC))
    f_true = 1.0 / (2 * np.pi * np.sqrt(true_l * C_REF))

    # Add noise to frequency measurement
    f_noisy = add_noise(f_true)
    f_noisy = max(f_noisy, 1e-3)  # prevent zero/negative frequency

    # Derive L from frequency
    measured_l = 1.0 / ((2 * np.pi * f_noisy) ** 2 * C_REF)

    error_pct = abs(measured_l - true_l) / true_l * 100
    return measured_l, error_pct


if __name__ == "__main__":
    # Quick sanity check
    print("=== measurement.py self-test ===\n")

    print("Resistance tests:")
    for r in [100, 1e3, 10e3, 100e3, 1e6]:
        val, err = measure_resistance(r)
        print(f"  True: {r:.0f} Ω  →  Measured: {val:.2f} Ω  |  Error: {err:.3f}%")

    print("\nCapacitance tests:")
    for c in [10e-9, 100e-9, 1e-6, 10e-6, 100e-6]:
        val, err = measure_capacitance(c)
        print(f"  True: {c*1e9:.1f} nF  →  Measured: {val*1e9:.2f} nF  |  Error: {err:.3f}%")

    print("\nInductance tests:")
    for l in [10e-6, 100e-6, 1e-3, 10e-3, 100e-3]:
        val, err = measure_inductance(l)
        print(f"  True: {l*1e6:.1f} µH  →  Measured: {val*1e6:.2f} µH  |  Error: {err:.3f}%")
