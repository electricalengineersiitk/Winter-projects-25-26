# Smart Multimeter — Software Simulation

## Part 1 — What did you build?

This project simulates an industry-grade digital multimeter capable of measuring **Resistance (R)**, **Capacitance (C)**, and **Inductance (L)** across a 10⁵ dynamic range. The auto-ranging engine monitors each reading against five logarithmically-spaced ranges and switches ranges automatically using a 3-sample hysteresis rule, preventing oscillation at range boundaries. The simulation achieves **≤ 0.9% average error** across all three modes with Gaussian ADC noise (σ = 0.5% of true value).

---

## Part 2 — How to set it up

```bash
git clone https://github.com/your-username/your-repo.git
cd your-repo/end_term/smart_multimeter
pip install -r requirements.txt
```

---

## Part 3 — How to run the simulation

```bash
python simulate.py
```

The script runs 50 log-spaced test values across all five ranges for each of R, C, and L. For every sample it adds simulated ADC noise, passes the result through the auto-ranging engine, and prints a detailed results table showing the true value, measured value, active range, and percentage error. Both accuracy and range-state plots are saved to `results/`.

---

## Part 4 — Results

| **Method**              | **R Error** | **C Error** | **L Error** |
|-------------------------|:-----------:|:-----------:|:-----------:|
| Fixed-range (no auto)   |    2.31%    |    1.70%    |    2.02%    |
| Your auto-ranging sim   |    0.89%    |    0.38%    |    0.70%    |

All three modes achieve well below the 2% target. The auto-ranging engine reduces error by 2–3× compared to a naive fixed-range baseline, with the largest gains at the extremes of the measurement range where fixed-range scaling penalties dominate.

---

## Part 5 — Known limitations

In real hardware, several factors would degrade accuracy beyond the simulated 0.5% Gaussian noise model. ADC quantisation error and integral non-linearity (INL) introduce systematic offsets that vary with input level — a 12-bit ADC at 3.3 V has ~0.8 mV LSB, which becomes significant for small voltage drops near the lower resistance end of the divider. Op-amp input offset voltage (~1–5 mV) and bias current (~10 nA) would shift the measured V_adc and distort the RC time constant, particularly for small capacitors (< 10 nF) where the charge time is only microseconds. Probe and PCB trace resistance (1–10 Ω) adds a fixed floor error that is most visible at the lowest resistance range (100 Ω). Temperature drift of R_ref (±50 ppm/°C for standard 1% resistors) would cause the calibration reference to shift with ambient temperature, introducing a slow drift term not captured by the static noise model used here.

---

## File Structure

```
end_term/
└── smart_multimeter/
    ├── README.md
    ├── requirements.txt
    ├── simulate.py       ← main entry point
    ├── autorange.py      ← auto-ranging engine with hysteresis
    ├── measurement.py    ← R, C, L physics formulas + noise model
    ├── protocol.py       ← OTG serial packet encode/decode
    └── results/
        ├── plot_accuracy.png
        └── plot_autorange.png
```

---

## Measurement Formulas

| Mode | Formula |
|------|---------|
| Resistance | `R = R_ref × V_adc / (V_ref − V_adc)` |
| Capacitance | `C = t / R_ref` where t = RC time constant |
| Inductance | `L = 1 / ((2πf)² × C_ref)` where f = LC resonant frequency |

---

## Auto-Ranging Logic

Five ranges per mode, 10× steps. Engine rules:

- `reading > 90% of range_max` → step **UP** (after 3 consecutive triggers)
- `reading < 10% of range_max` → step **DOWN** (after 3 consecutive triggers)  
- `10–90%` → **SETTLED**, report value
- Above all ranges → **OL** (overload)

The 3-sample hysteresis requirement prevents range oscillation at boundary values.

---

## OTG Protocol (Bonus)

`protocol.py` implements a 12-byte serial packet for transmitting readings over USB OTG to a mobile app:

```
[0]    START   = 0xAA
[1]    MODE    = 0x01(R) | 0x02(C) | 0x03(L)
[2]    RANGE   = 1–5
[3-6]  VALUE   = IEEE 754 float32
[7-8]  ERROR   = uint16 (error_pct × 100)
[9]    STATUS  = 0x00 SETTLED | 0x01 UP | 0x02 DOWN | 0xFF OL
[10]   XOR checksum
[11]   STOP    = 0x55
```
