"""
autorange.py — Auto-ranging engine for R, C, and L measurements.

Algorithm:
  1. reading > 90% of current range max  →  step UP
  2. reading < 10% of current range max  →  step DOWN
  3. 10–90%  →  SETTLED, report value

Hysteresis: requires 3 consecutive out-of-range readings before switching.
Safety fallback: if reading exceeds all ranges, returns "OL" (overload).
"""

# ─── Range tables ─────────────────────────────────────────────────────────────
# Each entry: (label, max_value)
RANGES = {
    "R": [
        ("100Ω",   100),
        ("1kΩ",    1_000),
        ("10kΩ",   10_000),
        ("100kΩ",  100_000),
        ("1MΩ",    1_000_000),
    ],
    "C": [
        ("10nF",   10e-9),
        ("100nF",  100e-9),
        ("1μF",    1e-6),
        ("10μF",   10e-6),
        ("100μF",  100e-6),
    ],
    "L": [
        ("10μH",   10e-6),
        ("100μH",  100e-6),
        ("1mH",    1e-3),
        ("10mH",   10e-3),
        ("100mH",  100e-3),
    ],
}

UP_THRESH   = 0.90   # step up  if reading > 90% of range max
DOWN_THRESH = 0.10   # step down if reading < 10% of range max
HYSTERESIS  = 3      # consecutive triggers needed to switch


class AutoRanger:
    """
    Stateful auto-ranging engine for one measurement mode.

    Parameters
    ----------
    mode : str
        One of "R", "C", or "L".
    """

    def __init__(self, mode: str):
        if mode not in RANGES:
            raise ValueError(f"Unknown mode '{mode}'. Choose from R, C, L.")
        self.mode      = mode
        self.ranges    = RANGES[mode]
        self.range_idx = 0          # start at lowest range
        self._up_count = 0
        self._dn_count = 0

    @property
    def current_range(self) -> tuple[str, float]:
        """Returns (label, max_value) of the active range."""
        return self.ranges[self.range_idx]

    def update(self, reading: float) -> dict:
        """
        Feed a new measurement into the engine.

        Returns a dict with:
          range_idx   : int   (0-based, 0 = lowest)
          range_label : str
          status      : "SETTLED" | "STEPPING_UP" | "STEPPING_DOWN" | "OL"
          value       : float | None  (None when OL)
        """
        max_ranges   = len(self.ranges)
        _, range_max = self.ranges[self.range_idx]

        ratio = reading / range_max if range_max > 0 else 0

        # ── Overload: above highest range ───────────────────────────────────
        if reading > self.ranges[-1][1]:
            return {
                "range_idx":   self.range_idx,
                "range_label": self.ranges[self.range_idx][0],
                "status":      "OL",
                "value":       None,
            }

        # ── Check step-up ────────────────────────────────────────────────────
        if ratio > UP_THRESH and self.range_idx < max_ranges - 1:
            self._up_count += 1
            self._dn_count  = 0
            if self._up_count >= HYSTERESIS:
                self.range_idx += 1
                self._up_count  = 0
                status = "STEPPING_UP"
            else:
                status = "SETTLED"   # not yet committed
        # ── Check step-down ──────────────────────────────────────────────────
        elif ratio < DOWN_THRESH and self.range_idx > 0:
            self._dn_count += 1
            self._up_count  = 0
            if self._dn_count >= HYSTERESIS:
                self.range_idx -= 1
                self._dn_count  = 0
                status = "STEPPING_DOWN"
            else:
                status = "SETTLED"
        # ── Settled ──────────────────────────────────────────────────────────
        else:
            self._up_count = 0
            self._dn_count = 0
            status = "SETTLED"

        return {
            "range_idx":   self.range_idx,
            "range_label": self.ranges[self.range_idx][0],
            "status":      status,
            "value":       reading,
        }

    def reset(self):
        """Reset ranger to lowest range."""
        self.range_idx = 0
        self._up_count = 0
        self._dn_count = 0
