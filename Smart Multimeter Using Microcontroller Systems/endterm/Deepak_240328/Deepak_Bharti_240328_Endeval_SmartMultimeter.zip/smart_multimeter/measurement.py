"""
measurement.py — R, C, L measurement functions with noise model.

Each function accepts a true component value, simulates ADC noise
(Gaussian, σ = 0.5% of true value), and returns (measured_value, error_pct).
"""

import numpy as np

# ─── Constants ────────────────────────────────────────────────────────────────
R_REF     = 100_000  # reference resistor for voltage divider (100 kΩ) — covers full 100Ω–1MΩ range
V_REF     = 3.3      # supply / reference voltage (V)
C_REF     = 100e-9   # reference capacitor for LC resonance (100 nF)
NOISE_STD = 0.005    # 0.5% of true value


def _add_noise(true_val: float) -> float:
    """Return true_val with Gaussian noise (σ = 0.5% of true_val)."""
    return np.random.normal(true_val, NOISE_STD * abs(true_val))


# ─── Resistance ───────────────────────────────────────────────────────────────
def measure_resistance(true_r: float) -> tuple[float, float]:
    """
    Voltage-divider method.
      V_adc = V_ref × R_true / (R_ref + R_true)
      R_meas = R_ref × V_adc / (V_ref − V_adc)

    Args:
        true_r: true resistance in ohms (Ω)
    Returns:
        (measured_r, error_pct)
    """
    v_adc_true = V_REF * true_r / (R_REF + true_r)
    v_adc      = _add_noise(v_adc_true)

    # Clamp to avoid division by zero near rail
    v_adc = np.clip(v_adc, 1e-6, V_REF - 1e-6)

    measured_r = R_REF * v_adc / (V_REF - v_adc)
    error_pct  = abs(measured_r - true_r) / true_r * 100
    return measured_r, error_pct


# ─── Capacitance ──────────────────────────────────────────────────────────────
def measure_capacitance(true_c: float) -> tuple[float, float]:
    """
    RC charge-discharge timing method.
      t = R_ref × C_true   (time to reach 63.2% of V_supply)
      C_meas = t_meas / R_ref

    Args:
        true_c: true capacitance in farads (F)
    Returns:
        (measured_c, error_pct)
    """
    t_true    = R_REF * true_c          # true time constant (s)
    t_meas    = _add_noise(t_true)
    t_meas    = max(t_meas, 1e-15)     # physical lower bound

    measured_c = t_meas / R_REF
    error_pct  = abs(measured_c - true_c) / true_c * 100
    return measured_c, error_pct


# ─── Inductance ───────────────────────────────────────────────────────────────
def measure_inductance(true_l: float) -> tuple[float, float]:
    """
    LC resonance frequency method.
      f_res = 1 / (2π √(L × C_ref))
      L_meas = 1 / ((2πf_meas)² × C_ref)

    Args:
        true_l: true inductance in henries (H)
    Returns:
        (measured_l, error_pct)
    """
    f_true    = 1.0 / (2 * np.pi * np.sqrt(true_l * C_REF))
    f_meas    = _add_noise(f_true)
    f_meas    = max(f_meas, 1e-6)      # physical lower bound

    measured_l = 1.0 / ((2 * np.pi * f_meas) ** 2 * C_REF)
    error_pct  = abs(measured_l - true_l) / true_l * 100
    return measured_l, error_pct
