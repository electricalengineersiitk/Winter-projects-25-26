"""
simulate.py — Main simulation entry point for Smart Multimeter.

Runs 50 test values spread across all 5 ranges for each of R, C, L.
For each value:
  1. Adds simulated ADC noise via measurement.py
  2. Passes result through the auto-ranging engine (autorange.py)
  3. Records true value, measured value, active range, and % error

Prints a results table and saves two plots to results/.
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from measurement import measure_resistance, measure_capacitance, measure_inductance
from autorange    import AutoRanger

# ─── Output directory ─────────────────────────────────────────────────────────
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

N_SAMPLES = 50  # test points per mode


# ─── Test-value generators ────────────────────────────────────────────────────
def _log_sweep(low, high, n):
    """Return n values log-spaced between low and high."""
    return np.logspace(np.log10(low), np.log10(high), n)


TEST_VALUES = {
    "R": _log_sweep(100,   1_000_000, N_SAMPLES),   # 100 Ω → 1 MΩ
    "C": _log_sweep(10e-9, 100e-6,    N_SAMPLES),   # 10 nF → 100 μF
    "L": _log_sweep(10e-6, 100e-3,    N_SAMPLES),   # 10 μH → 100 mH
}

MEASURE_FN = {
    "R": measure_resistance,
    "C": measure_capacitance,
    "L": measure_inductance,
}

UNITS = {"R": "Ω", "C": "F", "L": "H"}


# ─── Fixed-range baseline (always uses middle range, no switching) ─────────────
def _fixed_range_error(mode: str, values):
    """Return array of % errors for a naive fixed-range simulation."""
    errors = []
    for v in values:
        _, err = MEASURE_FN[mode](v)
        # Fixed range adds extra scale penalty: ±2% additive when out of mid-range
        mid = np.median(values)
        scale_penalty = 2.0 if (v < mid / 10 or v > mid * 10) else 0.5
        errors.append(err + scale_penalty)
    return np.array(errors)


# ─── Core simulation ──────────────────────────────────────────────────────────
def run_simulation(mode: str):
    """
    Run 50-sample sweep for a given mode.
    Returns list of dicts with simulation records.
    """
    ranger  = AutoRanger(mode)
    values  = TEST_VALUES[mode]
    records = []

    for i, true_val in enumerate(values):
        measured_val, error_pct = MEASURE_FN[mode](true_val)
        state = ranger.update(measured_val)

        records.append({
            "idx":         i + 1,
            "true_val":    true_val,
            "meas_val":    measured_val,
            "error_pct":   error_pct,
            "range_idx":   state["range_idx"] + 1,   # 1-based for readability
            "range_label": state["range_label"],
            "status":      state["status"],
        })

    return records


# ─── Printing ─────────────────────────────────────────────────────────────────
def print_results(mode: str, records: list):
    col = 14
    header = (
        f"{'#':>3}  "
        f"{'True Value':>{col}}  "
        f"{'Measured':>{col}}  "
        f"{'Error %':>8}  "
        f"{'Range':>8}  "
        f"Status"
    )
    sep = "─" * len(header)
    print(f"\n{'═'*len(header)}")
    print(f"  Mode: {mode}  ({UNITS[mode]})")
    print(sep)
    print(header)
    print(sep)
    for r in records:
        print(
            f"{r['idx']:>3}  "
            f"{r['true_val']:>{col}.4e}  "
            f"{r['meas_val']:>{col}.4e}  "
            f"{r['error_pct']:>8.3f}  "
            f"{r['range_label']:>8}  "
            f"{r['status']}"
        )
    avg = np.mean([r["error_pct"] for r in records])
    print(sep)
    print(f"  Average error: {avg:.3f}%")
    print(f"{'═'*len(header)}\n")


def print_summary_table(avg_errors: dict):
    """Print comparison table vs fixed-range baseline."""
    print("\n" + "="*60)
    print("  SUMMARY — Auto-ranging vs Fixed-range baseline")
    print("="*60)
    print(f"  {'Method':<30} {'R Error':>8} {'C Error':>8} {'L Error':>8}")
    print("-"*60)

    fixed = {}
    for mode in ("R", "C", "L"):
        fixed_errs = _fixed_range_error(mode, TEST_VALUES[mode])
        fixed[mode] = np.mean(fixed_errs)

    print(
        f"  {'Fixed-range (no auto)':<30} "
        f"{fixed['R']:>7.2f}%  {fixed['C']:>7.2f}%  {fixed['L']:>7.2f}%"
    )
    print(
        f"  {'Your auto-ranging sim':<30} "
        f"{avg_errors['R']:>7.2f}%  {avg_errors['C']:>7.2f}%  {avg_errors['L']:>7.2f}%"
    )
    print("="*60 + "\n")


# ─── Plots ────────────────────────────────────────────────────────────────────
def plot_accuracy(all_records: dict, avg_errors: dict):
    """Plot 1 — Accuracy vs Input Value (log-scale X)."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle("Plot 1 — Measurement Accuracy vs Input Value", fontsize=14, fontweight="bold")

    for ax, mode in zip(axes, ("R", "C", "L")):
        records   = all_records[mode]
        true_vals = np.array([r["true_val"]  for r in records])
        auto_errs = np.array([r["error_pct"] for r in records])
        fixed_err = _fixed_range_error(mode, true_vals)

        ax.semilogx(true_vals, fixed_err, "r--", linewidth=1.5,
                    label="Fixed-range baseline", alpha=0.8)
        ax.semilogx(true_vals, auto_errs, "b-o", linewidth=1.8,
                    markersize=3, label="Auto-ranging sim")

        ax.set_title(f"Mode: {mode}", fontsize=12)
        ax.set_xlabel(f"True Value ({UNITS[mode]}, log scale)", fontsize=10)
        ax.set_ylabel("% Measurement Error", fontsize=10)
        ax.legend(fontsize=9)
        ax.grid(True, which="both", linestyle="--", alpha=0.4)
        ax.set_ylim(bottom=0)

    plt.tight_layout()
    path = os.path.join(RESULTS_DIR, "plot_accuracy.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Saved: {path}")


def plot_autorange(all_records: dict):
    """Plot 2 — Auto-Range State Over Time."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle("Plot 2 — Auto-Range State Over Test Samples", fontsize=14, fontweight="bold")

    for ax, mode in zip(axes, ("R", "C", "L")):
        records = all_records[mode]
        idxs    = [r["idx"]       for r in records]
        ranges  = [r["range_idx"] for r in records]

        ax.step(idxs, ranges, where="post", linewidth=2, color="steelblue")
        ax.scatter(idxs, ranges, s=18, color="steelblue", zorder=3)

        ax.set_title(f"Mode: {mode}", fontsize=12)
        ax.set_xlabel("Test Sample Index", fontsize=10)
        ax.set_ylabel("Active Range (1 = lowest)", fontsize=10)
        ax.set_ylim(0.5, 5.5)
        ax.set_yticks([1, 2, 3, 4, 5])
        ax.grid(True, linestyle="--", alpha=0.4)

    plt.tight_layout()
    path = os.path.join(RESULTS_DIR, "plot_autorange.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  Saved: {path}")


# ─── Main ─────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "━"*60)
    print("  Smart Multimeter — Simulation")
    print("  Modes: R (Resistance), C (Capacitance), L (Inductance)")
    print(f"  Samples per mode: {N_SAMPLES}  |  Noise σ = 0.5% of true value")
    print("━"*60)

    all_records = {}
    avg_errors  = {}

    for mode in ("R", "C", "L"):
        records = run_simulation(mode)
        all_records[mode] = records
        avg_errors[mode]  = np.mean([r["error_pct"] for r in records])
        print_results(mode, records)

    print_summary_table(avg_errors)

    print("  Generating plots …")
    plot_accuracy(all_records, avg_errors)
    plot_autorange(all_records)
    print("\n  Done. Check results/ for plots.\n")


if __name__ == "__main__":
    main()
