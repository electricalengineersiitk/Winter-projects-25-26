"""
protocol.py — OTG Serial Packet Format for Smart Multimeter.

Packet structure (12 bytes, little-endian):
  [0]     : START byte  = 0xAA
  [1]     : MODE        = 0x01 (R) | 0x02 (C) | 0x03 (L)
  [2]     : RANGE_IDX   = 0x01 – 0x05
  [3..6]  : VALUE_F32   = 4-byte IEEE 754 float (measured value)
  [7..8]  : ERROR_U16   = error_pct × 100 (0.01% resolution, uint16)
  [9]     : STATUS      = 0x00 SETTLED | 0x01 STEPPING_UP | 0x02 STEPPING_DOWN | 0xFF OL
  [10]    : CHECKSUM    = XOR of bytes [0..9]
  [11]    : STOP byte   = 0x55

Usage example:
  from protocol import encode_packet, decode_packet
  pkt = encode_packet(mode="R", range_idx=2, value=4750.3, error_pct=0.42, status="SETTLED")
  result = decode_packet(pkt)
"""

import struct

START = 0xAA
STOP  = 0x55

MODE_MAP = {"R": 0x01, "C": 0x02, "L": 0x03}
MODE_INV = {v: k for k, v in MODE_MAP.items()}

STATUS_MAP = {
    "SETTLED":      0x00,
    "STEPPING_UP":  0x01,
    "STEPPING_DOWN":0x02,
    "OL":           0xFF,
}
STATUS_INV = {v: k for k, v in STATUS_MAP.items()}


def _checksum(data: bytes) -> int:
    """XOR checksum over provided bytes."""
    result = 0
    for b in data:
        result ^= b
    return result


def encode_packet(
    mode: str,
    range_idx: int,
    value: float,
    error_pct: float,
    status: str,
) -> bytes:
    """
    Encode a measurement result into a 12-byte OTG serial packet.

    Parameters
    ----------
    mode      : "R", "C", or "L"
    range_idx : active range index (1-based, 1–5)
    value     : measured component value (float)
    error_pct : percentage error (0.00 – 99.99)
    status    : "SETTLED" | "STEPPING_UP" | "STEPPING_DOWN" | "OL"

    Returns
    -------
    bytes : 12-byte packet
    """
    mode_byte   = MODE_MAP.get(mode, 0x00)
    range_byte  = max(1, min(5, int(range_idx)))
    value_bytes = struct.pack("<f", float(value))
    error_int   = int(round(error_pct * 100))
    error_bytes = struct.pack("<H", min(error_int, 0xFFFF))
    status_byte = STATUS_MAP.get(status, 0x00)

    payload = bytes([START, mode_byte, range_byte]) + value_bytes + error_bytes + bytes([status_byte])
    cs      = _checksum(payload)

    return payload + bytes([cs, STOP])


def decode_packet(packet: bytes) -> dict | None:
    """
    Decode a 12-byte OTG serial packet.

    Returns a dict with parsed fields, or None if the packet is invalid.
    """
    if len(packet) != 12:
        return None
    if packet[0] != START or packet[11] != STOP:
        return None

    expected_cs = _checksum(packet[:10])
    if packet[10] != expected_cs:
        return None

    mode      = MODE_INV.get(packet[1], "?")
    range_idx = packet[2]
    value     = struct.unpack("<f", packet[3:7])[0]
    error_pct = struct.unpack("<H", packet[7:9])[0] / 100.0
    status    = STATUS_INV.get(packet[9], "UNKNOWN")

    return {
        "mode":      mode,
        "range_idx": range_idx,
        "value":     value,
        "error_pct": error_pct,
        "status":    status,
    }


# ─── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("OTG Protocol Self-Test\n" + "="*40)
    test_cases = [
        ("R", 2, 4750.3,  0.42, "SETTLED"),
        ("C", 3, 0.47e-6, 0.85, "STEPPING_UP"),
        ("L", 5, 47e-3,   1.10, "SETTLED"),
        ("R", 1, 0.0,     0.00, "OL"),
    ]
    for args in test_cases:
        pkt    = encode_packet(*args)
        result = decode_packet(pkt)
        print(f"  Encoded ({args[0]}, range={args[1]}, val={args[2]:.4e}): "
              f"{pkt.hex().upper()}")
        print(f"  Decoded: {result}\n")
